# upgrade packages using winget
#winget upgrade --id=7zip.7zip -e
winget upgrade --id=CrystalDewWorld.CrystalDiskInfo -e
winget upgrade --id=REALiX.HWiNFO -e
winget upgrade --id=Klocman.BulkCrapUnupgradeer -e
winget upgrade --id=nomacs.nomacs -e
winget upgrade --id=Microsoft.VCRedist.2015+.x64 -e
winget upgrade --id=Microsoft.VCRedist.2015+.x86 -e
winget upgrade --id=9NKSQGP7F2NH -e
winget upgrade --id=SumatraPDF.SumatraPDF -e
winget upgrade --id=CodeSector.TeraCopy -e
winget upgrade --id=M2Team.NanaZip -e
winget upgrade --id=CrystalRich.LockHunter -e 