Method I

Open PowerShell as an administrator.

Install-PackageProvider -Name "NuGet" -Force
Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted

Install-Script winget-install -Force

============================================
Method II

irm asheroto.com/winget | iex

============================================
Method III

Before install software update winget using winget-install.ps1

Open PowerShell as an administrator.

PowerShell.exe -ExecutionPolicy Bypass -File C:\users\xx\Desktop\winget-install.ps1

Navigate to the directory where your script (winget-install.ps1) is located: "cd path\to\script"

Run the script by typing: "winget-install.ps1" [without Quotation marks].

Check for update using the link below.
https://github.com/asheroto/winget-install
============================================
Method I

Open PowerShell as an administrator.

PowerShell.exe -ExecutionPolicy Bypass -File C:\users\xx\Desktop\install-apps.ps1

xx :- name of the system

============================================
Method II

Open PowerShell as an administrator.

Enable PowerShell execution "Set-ExecutionPolicy RemoteSigned -Force"

Navigate to the directory where your script (install-apps.ps1) is located: "cd path\to\script"

Run the script by typing: ".\install-apps.ps1" [without Quotation marks].

Revert PowerShell execution "Set-ExecutionPolicy Default -Force"
