https://www.sordum.org/9480/defender-control-v2-1/

https://forums.mydigitallife.net/threads/office-r-tool-project.84450/
