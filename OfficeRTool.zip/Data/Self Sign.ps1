﻿# Certificate Stores
# certmgr.msc => Personal => Certificates ...

# How do I create a self-signed certificate for code signing on Windows?
# https://stackoverflow.com/questions/84847/how-do-i-create-a-self-signed-certificate-for-code-signing-on-windows/51443366#51443366

cls
Write-Host

if (-not (
  [Security.Principal.WindowsIdentity]::GetCurrent().Groups | ? Value -match "S-1-5-32-544")) {
  write-host
  "Make sure to run this script as Administrator"
  write-host
  pause
  [Environment]::Exit(1)
}

$files       = Get-ChildItem -Recurse
$Pattern     = "^(.)(ps1|vbs|exe|dll)$"
$case        = [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
$certificate = "C:\windows\code_signing.crt"
$Thumbprint  = (Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert)

if (-not $Thumbprint) {
  New-SelfSignedCertificate -DnsName admin@officertool.org -Type CodeSigning -CertStoreLocation cert:\CurrentUser\My
  Export-Certificate -Cert (Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert)[0] -FilePath $certificate
  certutil -addstore -f "root" $certificate
  certutil -addstore -f "TrustedPublisher" $certificate

  # send ... annoying pop-up ... LOL
  #Import-Certificate -FilePath C:\windows\code_signing.crt -Cert Cert:\CurrentUser\TrustedPublisher -ErrorAction Stop
  #Import-Certificate -FilePath C:\windows\code_signing.crt -Cert Cert:\CurrentUser\Root -ErrorAction Stop

  $Thumbprint = (Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert)
  if (-not $Thumbprint) {
	  throw "ERROR :: Failed to create Fake Certificate"
	  return
  }
}

$files|?{[REGEX]::IsMatch($_.Extension,$Pattern,$case)}|%{Set-AuthenticodeSignature $_.FullName -Certificate $Thumbprint[0] -Force -ErrorAction SilentlyContinue -Verbose }
Write-Host
Pause
return

# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUtybBM8DwE/rVZlKWou6fh8cC
# l5ygggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFGBL
# drZIxp+QjXwHSorDH7PfLHcnMA0GCSqGSIb3DQEBAQUABIIBAJBG0tt7q5cS/YwG
# cV3AYZ52ZI0poAihJ52GRHE28VX2IW+yUBJimyvWTXgPJ2vXUxkMkXSEnydPJxN5
# feMZres9S8IvGVR2cqTGytYBF/MyrveqBCAAwA35/lwYOw5XD1M974gJ9GNDwszn
# 35mx8Y0gTlNpjfczLjNFPz8/+4Wa8HiwLeAfTBY/VB5+H/rBXtx2m4pjf4wPx5yA
# DdGoJnSP0tVgLVycB1jqb5d0Rjca2IS38c+xcmi32YzSYKmGDdkOEs0Jqiq4rj4D
# GRLll20n25ukk3KeHwZikNkvF0qGutwSO5xYbDKmysoJFor/Chj991AhkhSeWEGo
# +L8/9cI=
# SIG # End signature block
