# powershell catch exception codes for wmi query
# https://stackoverflow.com/questions/29923588/powershell-catch-exception-codes-for-wmi-query

# gwim ... gcim ... maybe i change it later ...
# gwmi is much better, GetPropertyValue, method invoke .. etc

if ($Args[0] -eq '/QUERY_BASIC') {
 $class = $Args[2];
 $value = @($Args[1]).Replace(' ','')
 $wmi_Object = gwmi -Query "select $($value) from $($class)" -ErrorAction SilentlyContinue
 if (-not $wmi_Object) { 
   return "Error:WMI_SEARCH_FAILURE" 
 }
 foreach ($item in $wmi_Object) {
  $line = '';
  $value.Split(",")|%{$line += ",$($item.GetPropertyValue("$_"))"}
  Write-Host $line
 }
 return
}

if ($Args[0] -eq '/QUERY_ADVENCED') {
 $class  = $Args[2];
 $filter = $Args[3];
 $value  = @($Args[1]).Replace(' ','')
 $wmi_Object = gwmi -Query "select $($value) from $($class) where ($($filter))" -ErrorAction SilentlyContinue
 if (-not $wmi_Object) { 
   return "Error:WMI_SEARCH_FAILURE" 
 }
 foreach ($item in $wmi_Object) {
  $line = '';
  $value.Split(",")|%{$line += ",$($item.GetPropertyValue("$_"))"}
  Write-Host $line
 }
 return
}

if ($Args[0] -eq '/ACTIVATE') {
 $CLASS = $Args[1]
 $ID    = $Args[2]
 $ErrorActionPreference = "Stop"
  try {
   $wmi_Object = gwmi -Query "select * from $($CLASS) where ID='$($ID)'"
   $wmi_Object.Activate()
   return "Error:0"
 }
 catch {
  # return wmi last error, in hex format
  $HResult = �{0:x}� -f  @($_.Exception).HResult
  return "Error:$($HResult)"
 }
}

if ($Args[0] -eq '/UninstallProductKey') {
 $CLASS  = $Args[1]
 $FILTER = $Args[2]
 $wmi_Object = gwmi -Query "select * from $($CLASS) where ($($FILTER))"
 if (-not $wmi_Object) { 
   return "Error:WMI_SEARCH_FAILURE" 
 }
 foreach ($item in $wmi_Object) {
  try {
	  $item.UninstallProductKey()
	  return "Error:0"
  }
  catch {
   # return wmi last error, in hex format
   $HResult = �{0:x}� -f  @($_.Exception).HResult
   return "Error:$($HResult)"
  }
 }
}

if ($Args[0] -eq '/InstallProductKey') {
 $KEY  = $Args[1]
 $ErrorActionPreference = "Stop"
 $LicensingService = gwmi -ClassName SoftwareLicensingService -ErrorAction SilentlyContinue 
 if (-not $LicensingService) {
	return "Error:CLASS_NOT_FOUND"
 }
 try {
  $LicensingService.InstallProductKey($KEY)
  return "Error:0"
 }
 catch {
  # return wmi last error, in hex format
  $HResult = �{0:x}� -f  @($_.Exception).HResult
  return "Error:$($HResult)"
 }
}

if ($Args[0] -eq '/InstallLicense') {
 $LicenseFile      = $Args[1]
 $ErrorActionPreference = "Stop"
 if([System.IO.File]::Exists($LicenseFile)-ne $true) {
	return "Error:FILE_NOT_FOUND"
 }
 $LicensingService = gwmi -ClassName SoftwareLicensingService -ErrorAction SilentlyContinue 
 if (-not $LicensingService) {
	return "Error:CLASS_NOT_FOUND"
 }
 try {
  $LicensingService.InstallLicense(
   [System.IO.File]::ReadAllText(
     $LicenseFile
  ))
  return "Error:0"
 }
 catch {
  # return wmi last error, in hex format
  $HResult = �{0:x}� -f  @($_.Exception).HResult
  return "Error:$($HResult)"
 }
}

return $null

# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUmML099fHx5EKwoaKmnzPKs/x
# 1EigggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFKIG
# X7xzqo/y13vpuIPkOC4st1fkMA0GCSqGSIb3DQEBAQUABIIBAFkZrKGlnrhcA8G2
# k8qioQOUFGMvPTItybyaUgSnkIgP1oM9OPp+SHqZxMVV5U1iSajcZZTt0/KwGv3e
# 6+ZDcFLyJn99nN6SW5rDksj5Fbb7dad0rPKMmF2b5gV6oC4ttXfO8MdAnGWJSlRK
# VQzg7R4bUE3UO5A8g0mxrNHJ0X+ovm/zFSIFXhdlqEdVwpy2/VobfQp9oeiwhWT1
# kkHfWlSWmtBvJMOnOdH7dSCxVw6GSuYorsOIHofV1nE6gHsFkmGw4dXISk36gHiV
# eexh05JJiJ/cEypBya4QmcaWXyI19lada4MHj6eJTU0g2C+KmtfzEEGY0vhwNy+T
# bsUu1Yk=
# SIG # End signature block
