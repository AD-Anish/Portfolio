﻿# Path to your DLL
$dllPath = $null
try {
  $dllPath = Join-Path $env:OfficeRToolpath "DATA\CORE\LibTSforge.dll"
}
catch {
  Write-Host "[ERROR] VARIABLE not found: OfficeRToolpath"
  return
}

# Function to check if a file exists
function Test-FileExists ($filePath) {
    return Test-Path -Path $filePath -PathType Leaf
}

# Function to load the DLL with better error checking
function Load-TSForgeDLL ($dllPath) {
    if (-not (Test-FileExists $dllPath)) {
        Write-Host "[ERROR] DLL not found at path: '$dllPath'"
        return $false
    }
    try {
        [Reflection.Assembly]::LoadFrom($dllPath) | Out-Null
        Write-Host "DLL loaded successfully." -ForegroundColor Green
        return $true
    }
    catch {
        Write-Host "[ERROR] Error loading the DLL: $($_.Exception.Message)"
        return $false
    }
}

# Function to WMI information for specific product ID
function Get-WmiInfo {
    param (
    [Parameter(Mandatory=$true)]
    [string]$tsactid)

    try {
        $query = "SELECT ID,Name,Description,LicenseStatus FROM SoftwareLicensingProduct WHERE ID='$tsactid'"
        $record = Get-WmiObject -Query $query -ErrorAction Stop
        if ($record) {
            return $record
        } else {
            Write-Verbose "No SoftwareLicensingProduct found with ID '$tsactid'."
            return $null
        }
    } catch {
        Write-Error "Error retrieving WMI information: $($_.Exception.Message)"
        return $null
    }
}

Write-Host
if (-not @(Load-TSForgeDLL -dllPath $dllPath)) {
  return
}


$tsactid = $env:ID_
$errcode = 0 # Initialize error code
$ver = [LibTSforge.Utils]::DetectVersion()
$prod = [LibTSforge.Utils]::DetectCurrentKey()

try {
    $info = Get-WmiInfo -tsactid $tsactid
    $prodName = $info.Name
    $prodDes = $info.Description

    if ($prodName) {
        $nameParts = $prodName -split ',', 2
        $prodName = if ($nameParts.Count -gt 1) { ($nameParts[1].Trim() -split '[ ,]')[0] } else { $null }
    }
    #[LibTSforge.Modifiers.GenPKeyInstall]::InstallGenPKey($ver, $prod, $tsactid)
    [LibTSforge.Activators.KMS4k]::Activate($ver, $prod, $tsactid)
    $info = Get-WmiInfo -tsactid $tsactid
    if ($info.LicenseStatus -eq 1) {
        if ($prodDes -match 'KMS' -and $prodDes -notmatch 'CLIENT') {
            [LibTSforge.Modifiers.KMSHostCharge]::Charge($ver, $tsactid, $prod)
            Write-Host "[$prodName] CSVLK is permanently activated with KMS4k." -ForegroundColor White -BackgroundColor DarkGreen
            Write-Host "[$prodName] CSVLK is charged with 25 clients for 30 days." -ForegroundColor White -BackgroundColor DarkGreen
        }
        else {
            Write-Host "[$prodName] is permanently activated with KMS4k." -ForegroundColor White -BackgroundColor DarkGreen
        }
    }
    else {
        Write-Host "[$prodName] activation has failed." -ForegroundColor White -BackgroundColor DarkRed
        $errcode = 3
    }	
}
catch {
    $errcode = 3
    #Write-Error "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
    Write-Host "[$prodName] activation has failed." -ForegroundColor White -BackgroundColor DarkRed
}