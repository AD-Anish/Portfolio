﻿function get_latest_version_WC {
	
	$url = '^https?:\/\/(.*).exe"$'
	$sku = 'ms.dlcfamilyid|ms.dlcproductid|ms.dwntype' # 'https?:\/\/(.*).exe'
	$tmp = join-path $env:windir -ChildPath 'temp\officedeploymenttool.raw'
	$lnk = 'https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117'

	if (test-path $tmp) {del $tmp | Out-Null}
	try {
	  (New-Object System.Net.WebClient).DownloadFile($lnk, $tmp)
	}
	catch {
	   return
	}
	if (!(test-path $tmp)) {
		return
	}
	
	foreach ($val in @(Get-Content $tmp)) {
	  if ($val -match $sku){
		sv -Name "sec" -Value $val -Scope global -force
		break;
	  }
	}
	
	if (!($sec)) {
	  return
	}
	
	foreach ($val in $sec.Split('=')) {
	  if ($val -match $url){
		return $val.TrimEnd('"')
	  }
	}
}

function get_latest_version_WR {
	
	$url = '^https?:\/\/(.*).exe$'
	$lnk = 'https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117'
	
	try {
		$ProgressPreference = 'SilentlyContinue'    # Subsequent calls do not display UI.
		$req = iwr -URI $lnk
		$ProgressPreference = 'Continue'            # Subsequent calls do display UI.
	}
	catch {
		$ProgressPreference = 'Continue'            # Subsequent calls do display UI.
		return
	}
	<# $uri = $req.Links | ? data-bi-cn -eq 'click here to download manually' #>
	$uri = $req.Links | ? href -match $url | select-object -first 1
	if ($uri) {
	  return @($uri).Href
	}
}

<# if ($env:terminalFound) {
	get_latest_version_WC;
	return
} #>

<# get_latest_version_WR
return #>

# 
get_latest_version_WR
return