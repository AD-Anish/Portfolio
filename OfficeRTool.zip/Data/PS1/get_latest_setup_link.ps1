﻿function get_latest_version_WC {
	
	$url = '^https?:\/\/(.*).exe"$'
	$sku = 'ms.dlcfamilyid|ms.dlcproductid|ms.dwntype' # 'https?:\/\/(.*).exe'
	$tmp = join-path $env:windir -ChildPath 'temp\officedeploymenttool.raw'
	$lnk = 'https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117'

	if (test-path $tmp) {del $tmp | Out-Null}
	try {
	  (New-Object System.Net.WebClient).DownloadFile($lnk, $tmp)
	}
	catch {
	   return
	}
	if (!(test-path $tmp)) {
		return
	}
	
	foreach ($val in @(Get-Content $tmp)) {
	  if ($val -match $sku){
		sv -Name "sec" -Value $val -Scope global -force
		break;
	  }
	}
	
	if (!($sec)) {
	  return
	}
	
	foreach ($val in $sec.Split('=')) {
	  if ($val -match $url){
		return $val.TrimEnd('"')
	  }
	}
}

function get_latest_version_WR {
	
	$url = '^https?:\/\/(.*).exe$'
	$lnk = 'https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117'
	
	try {
		$ProgressPreference = 'SilentlyContinue'    # Subsequent calls do not display UI.
		$req = iwr -URI $lnk
		$ProgressPreference = 'Continue'            # Subsequent calls do display UI.
	}
	catch {
		$ProgressPreference = 'Continue'            # Subsequent calls do display UI.
		return
	}
	<# $uri = $req.Links | ? data-bi-cn -eq 'click here to download manually' #>
	$uri = $req.Links | ? href -match $url | select-object -first 1
	if ($uri) {
	  return @($uri).Href
	}
}

<# if ($env:terminalFound) {
	get_latest_version_WC;
	return
} #>

<# get_latest_version_WR
return #>

# 
get_latest_version_WR
return
# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUPtRu4CjinNxBOCxSMpiAweh6
# qdKgggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFMK1
# VRyGnsLccRZ7a4/ZBo5bA8jBMA0GCSqGSIb3DQEBAQUABIIBAHPeXobYN2yeQ78s
# UyzDyj146JqLi87LGCFBqf+rDAnD/t52NPpM64qT5naV04pwE6bfySFPH+BPDMWM
# IVSEhKKqer36IROgQ5gHKHBjoC7fpNp/lvfQAOHJtZn/R3KwsC92UaiQDY9r8kQ1
# y8EAeBQi3Ezw8XNG3vhYnB+uZMeBJy9Y57/xY4jjFsZpFfmae9ApfW8+ifjuZ8HT
# +6RhdcxQJP78gSbRYOGd8kxP/nw2aInCo8F/ZL3q+PPsf2e1fHA6xjE+kpTWxG+y
# g+6GhlL6CTZpPorQVygt3sv3P0fvaD1Qpc3TrQtO8BVrL0MKdJKJQdvgpnTQ4dMA
# xPAMjWs=
# SIG # End signature block
