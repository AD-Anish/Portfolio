# Check the internet performance using Powershell?
# https://www.joakimnordin.com/is-it-possible-to-check-the-internet-performance-at-a-clients-network-using-powershell/

if ($Args[0] -match 'Get') {  $Speedtest = cmd /c "$env:speedtest" --format=json --accept-license --accept-gdpr 2>$null | ConvertFrom-Json
  if (-not $Speedtest) {throw 'Fail to get information'}  [PSCustomObject]$SpeedObject = @{  	downloadspeed = [math]::Round($Speedtest.download.bandwidth / 1000000 * 8, 2)  	uploadspeed   = [math]::Round($Speedtest.upload.bandwidth / 1000000 * 8, 2)  	packetloss    = [math]::Round($Speedtest.packetLoss)  	isp           = $Speedtest.isp  	ExternalIP    = $Speedtest.interface.externalIp  	InternalIP    = $Speedtest.interface.internalIp  	UsedServer    = $Speedtest.server.host  	URL           = $Speedtest.result.url  	Jitter        = [math]::Round($Speedtest.ping.jitter)  	Latency       = [math]::Round($Speedtest.ping.latency)  }  return @(    [Math]::Round($SpeedObject.downloadspeed / 10))
}

if ($Args[0] -match 'Set') {
  $gcr  = Get-Content -Encoding Ascii .\Settings.ini -ErrorAction Stop;
  for ($num = 1 ; $num -le $gcr.Length ; $num++) {
    if ($gcr[$num] -match 'Speed_Limit') {
      $gcr[$num]="Speed_Limit=$($env:Speed_Limit)"
      break;
    }}
  Set-Content -value $gcr -Encoding Ascii .\Settings.ini
  return;
}