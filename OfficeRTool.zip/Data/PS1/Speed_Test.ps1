# Check the internet performance using Powershell?
# https://www.joakimnordin.com/is-it-possible-to-check-the-internet-performance-at-a-clients-network-using-powershell/

if ($Args[0] -match 'Get') {  $Speedtest = cmd /c "$env:speedtest" --format=json --accept-license --accept-gdpr 2>$null | ConvertFrom-Json
  if (-not $Speedtest) {throw 'Fail to get information'}  [PSCustomObject]$SpeedObject = @{  	downloadspeed = [math]::Round($Speedtest.download.bandwidth / 1000000 * 8, 2)  	uploadspeed   = [math]::Round($Speedtest.upload.bandwidth / 1000000 * 8, 2)  	packetloss    = [math]::Round($Speedtest.packetLoss)  	isp           = $Speedtest.isp  	ExternalIP    = $Speedtest.interface.externalIp  	InternalIP    = $Speedtest.interface.internalIp  	UsedServer    = $Speedtest.server.host  	URL           = $Speedtest.result.url  	Jitter        = [math]::Round($Speedtest.ping.jitter)  	Latency       = [math]::Round($Speedtest.ping.latency)  }  return @(    [Math]::Round($SpeedObject.downloadspeed / 10))
}

if ($Args[0] -match 'Set') {
  $gcr  = Get-Content -Encoding Ascii .\Settings.ini -ErrorAction Stop;
  for ($num = 1 ; $num -le $gcr.Length ; $num++) {
    if ($gcr[$num] -match 'Speed_Limit') {
      $gcr[$num]="Speed_Limit=$($env:Speed_Limit)"
      break;
    }}
  Set-Content -value $gcr -Encoding Ascii .\Settings.ini
  return;
}
# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU5VrPGFeUg9dJVni+rnTlAD3d
# msqgggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFIxF
# rhkRdSRCpiSq5ErxR+Vvn6cfMA0GCSqGSIb3DQEBAQUABIIBAHM7SsZZslKx+VUB
# JEPTRm+kQpls8+zRlPCKynPazRig/2v7stAVNm2qTs7JJNgbGRoTuStpha0jLt1D
# FVbIqg3iKVi9GnU2c1/0IjrRsmifMqFIFLyjmWU2zcR0Ib2Q5o4Er1OL7zbS1Ng+
# OAEq0iMu+KtenLHkIEmPW15IW+o7f2hEUok37SjXdQobDthzuObzerZ9/epmGefU
# tu7XDYCJji36JmLboaBxkwKP1WzCYv+dT7vgT6GAZp8J0qN44kWnrJy5xgJKDMoR
# j+YHX/Qh94KqCqmbDBF5AGD6rSM1bM2NmcJ/Wm/X9K5NesRrcXHCxWTxuFkK0Z54
# QRFqMk8=
# SIG # End signature block
