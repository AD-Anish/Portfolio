﻿
timeout 2 | Out-Null
if ($env:S_ID) {
  $id = [INT]$env:S_ID
  while (@(gcim win32_process | where {($_.ParentProcessId -eq $id) -and ($_.Name -eq 'OfficeClickToRun.exe')}).Count -eq 0){
	timeout 2 | Out-Null
	if (@(gcim win32_process | where ProcessId -eq $id ).Count -eq 0) { 
	  echo 'error occurred during initialization of installation'
	  echo ''
	  exit
	}
  }
  echo 'Please hold until the setup is finished'
  echo ''
  while (@(gcim win32_process | where {($_.ParentProcessId -eq $id) -and ($_.Name -eq 'OfficeClickToRun.exe')}).Count -GT 0) {
    timeout 2 | out-null
  }
}