﻿
timeout 2 | Out-Null
if ($env:S_ID) {
  $id = [INT]$env:S_ID
  while (@(gcim win32_process | where {($_.ParentProcessId -eq $id) -and ($_.Name -eq 'OfficeClickToRun.exe')}).Count -eq 0){
	timeout 2 | Out-Null
	if (@(gcim win32_process | where ProcessId -eq $id ).Count -eq 0) { 
	  echo 'error occurred during initialization of installation'
	  echo ''
	  exit
	}
  }
  echo 'Please hold until the setup is finished'
  echo ''
  while (@(gcim win32_process | where {($_.ParentProcessId -eq $id) -and ($_.Name -eq 'OfficeClickToRun.exe')}).Count -GT 0) {
    timeout 2 | out-null
  }
}
# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUzjGjZY+r+AlumkwHj/kwXboN
# qD2gggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFOLa
# Go0XWCN3rbsjZxBA0SWarsmZMA0GCSqGSIb3DQEBAQUABIIBAFFcmEeybHBbFdQX
# Urh4iSxK6j4v+oYu0ovwgsGcaer6B0M6tscSTx6Skcj10GiUB9sFwdJeRWkqx8Rf
# 6SmdUPT5i/PUpIwId+vsAaoaDjtSwgAGsuPFyvNx2WN/V/W8vr8Qs7KRCzjww3eP
# +l8ekEBeSHQiy1nbN652qR7DbMxqvTi/efJiyKNkRFo8sjgfHL2GHdGfd2nc+KUc
# pLv0Fd1+tn/q1T48kT5FFeis757h66aATm0zenbd7MJgfRXTTzkOol4kGiqEzFY9
# 7U+GTkk2hyfp14zCjl0bXVS9s4ghmp4qUH1ytLvGfNsiYDNGjYDwc3f72PqNKCaZ
# U4YNgIA=
# SIG # End signature block
