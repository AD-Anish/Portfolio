
<#
version      : 3.0
Release Date : 09-02-2024
Made By      : Dark Dinosaur, MDL
#>

Function Office_Offline_Install (
  [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory)]
  [String] $FFNRoot,

  [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory)]
  [String] $oVer,

  [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory)]
  [String] $oApps,

  [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory)]
  [String] $mLang,

  [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory)]
  [String] $aLang,

  [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
  [String] $Exclude
  )
{
  $type = "LOCAL"
  $vSys = $ENV:instarch1
  $bUrl = """$(Get-Location)"""
  $sUrl="http://officecdn.microsoft.com/pr/$FFNRoot"
  $sCulture = $aLang.TrimStart('_')
  $misc = "flt.useoutlookshareaddon=unknown flt.useofficehelperaddon=unknown"

  $sAppList = ''
  $oApps.TrimStart(',').Split(',') | % {$sAppList += "$($_).16_$($sCulture)_x-none|"}
  $sAppList = $sAppList.TrimEnd('|')
  
  echo ''
  echo 'Please hold until the setup is finished'
  echo ''
  
  Push-Location "$ENV:CommonProgramFiles\Microsoft Shared\ClickToRun"
  start OfficeClickToRun.exe -args "platform=$vSys culture=$mLang productstoadd=$sAppList $($Exclude) cdnbaseurl.16=$sUrl baseurl.16=$bUrl version.16=$oVer mediatype.16=$type sourcetype.16=$type updatesenabled.16=True acceptalleulas.16=True displaylevel=True bitnessmigration=False deliverymechanism=$FFNRoot $misc" -Wait
}

if ($args[5]) {
  Office_Offline_Install $args[0] $args[1] $args[2] $args[3] $args[4] $args[5]
  return
}

Office_Offline_Install $args[0] $args[1] $args[2] $args[3] $args[4]
return


# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU3j3RKty8ZFKFM1VHkJ7n2Tfg
# UbqgggM2MIIDMjCCAhqgAwIBAgIQSe49BypwLKhOHkzMeRKLBzANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA2
# MTYxMjI3WhcNMzAwMTA2MTYyMjI3WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDLZq+Rmrz4
# wwNvgAZVzvbOmj1RlUll7htG/vIJurDabWNvIbYBxycLrzEAJKeuuO8TTtodlhCF
# kvCtzO2gU47wKwqoIK9p5orB9f0xasuxtu7EeIRvXZLpBjKQ20Fnzed6peoPupEb
# 5+2FIjAbM3ErtSbmC7XDhSLhAheV8+Urio/vv7zhiI0JYsfKtcZnbFBG8h5WOoYS
# k7vEF6nW4OleuM6oGuprq7OWDYGLa9sarX8mjNu0CPDgvxoE6vAiOY6lXgT9GoSn
# EOgpn8OOhpBp9ERPzP6Qq6qetl/+wYGkYbQGz7v6fPDQ4ATnGFIfc9G+qICE8iZs
# TV+bgDYjyMUJAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFDIRoZpOPb0eh3mSqlUpHSSgioiqMA0GCSqGSIb3DQEBCwUAA4IBAQCe7S09
# 5VqCa9rw0s6FdNqvHOftRgRf1or04i7ZuV3jffN/rValXj8O7GtTRQ9ZFhGInjZ/
# 5UVyLPnhVqVwWzNpqFgTL5/Y0joFQ99GQfv1f5UUt6U4jNjjSTZNdVa3C9iwV4IQ
# jaRhGEQqsvqsOadezbX9jlIpXBKxmua70/cUj8Ub0UBT+jrt3ztqsX/Ei/wrorbh
# 8qS1rgYmi493hgQgKxSG/7tZ5PvbljEO5KPEMagKF6u4XX1B7Mz0DQAJcFUnTsNy
# D/Tj8nc03aYnF8NRkUyRYPhbIgpiY9e7/ivBY+4gF20ONc1Cy8+zqgSn17mF1QTD
# TOzL7jtV+7ROPKxOMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEEnuPQcqcCyoTh5MzHkSiwcwCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFLCK
# k8u/RVMPdfslz03pLfvssG5SMA0GCSqGSIb3DQEBAQUABIIBAK1RQWFXQhdPEgYQ
# 8qNYXFw1EyUe2oOQgk6Aq71iSL7rRKEMAdLcnRyWJR1oGboIhv8mf9YmmO1TFKog
# DFymgGhZd0uhGabklqX3DwSojzzqq/D2DnRuT9bG3IhQIOFKstfKak4cDBnkdhj2
# T96kn0WZw8gQSFoOgdcdWkoKJhzuyZeH16Edo1r+rZtkytK4WOlvmckmje8INLkS
# JiOxWPCuA3pDTbIc7gXD5LoI5fGkH8MvAk9fNl5pPy5vMweFb0C1m+fcGI0yZ3qN
# besXPqDTMn+U3rw1slIYf8iQaEh32CGxRtF4ML2XW7tLmrYRoCEakKen1lYBOK21
# RtNLC6s=
# SIG # End signature block
