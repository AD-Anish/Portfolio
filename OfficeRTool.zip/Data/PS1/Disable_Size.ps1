<# disabling the cmd close button by batch command #>
<# https://stackoverflow.com/questions/13763134/disabling-the-cmd-close-button-by-batch-command #>

$code = @'
using System;
using System.Diagnostics;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace CloseButtonToggle {

 internal static class WinAPI {
   [DllImport("kernel32.dll")]
   internal static extern IntPtr GetConsoleWindow();

   [DllImport("user32.dll")]
   [return: MarshalAs(UnmanagedType.Bool)]
   internal static extern bool DeleteMenu(IntPtr hMenu,
                          uint uPosition, uint uFlags);

   [DllImport("user32.dll")]
   [return: MarshalAs(UnmanagedType.Bool)]
   internal static extern bool DrawMenuBar(IntPtr hWnd);

   [DllImport("user32.dll")]
   internal static extern IntPtr GetSystemMenu(IntPtr hWnd,
              [MarshalAs(UnmanagedType.Bool)]bool bRevert);

   const uint SC_CLOSE     = 0xF060;
   const uint SC_MAXIMIZE  = 0xF030;
   const uint SC_MINIMIZE  = 0xF020;
   const uint SC_SIZE      = 0xF000;
   const uint MF_BYCOMMAND = 0;

   internal static void ChangeCurrentState(IntPtr Console, bool state) {
     IntPtr hMenu = GetSystemMenu(Console, state);
	 DeleteMenu(hMenu, SC_SIZE, MF_BYCOMMAND);
	 DeleteMenu(hMenu, SC_MAXIMIZE, MF_BYCOMMAND);
     DrawMenuBar(Console);
   }
   internal static void ChangeCurrentState(bool state) {
	 IntPtr Console = GetConsoleWindow();
     IntPtr hMenu = GetSystemMenu(Console, state);
	 DeleteMenu(hMenu, SC_SIZE, MF_BYCOMMAND);
	 DeleteMenu(hMenu, SC_MAXIMIZE, MF_BYCOMMAND);
     DrawMenuBar(Console);
   }
 }

 public static class Status {
   public static void Disable(IntPtr Console) {
     WinAPI.ChangeCurrentState(Console, false); //its 'true' if need to enable
   }
   public static void Disable() {
     WinAPI.ChangeCurrentState(false); //its 'true' if need to enable
   }
 }
}
'@

Add-Type $code;
if (!($env:terminalFound)) {
	[CloseButtonToggle.Status]::Disable();
	exit;
}
if ($env:PROC_ID) {
	$ptr = @(Get-Process |where id -eq $env:PROC_ID).MainWindowHandle;
	[CloseButtonToggle.Status]::Disable($ptr);
	exit
}
if ($env:terminalFound) {
	foreach ($ptr in @(Get-Process -Name "windowsterminal" -ErrorAction SilentlyContinue).MainWindowHandle)  {
		[CloseButtonToggle.Status]::Disable($ptr);
	}
	exit
}
# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQURwjxws6TWIfhmkvJNBW0mrSF
# 2nGgggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFOtX
# jXFELtRC0bZQP7hJ0oiX+LLwMA0GCSqGSIb3DQEBAQUABIIBAEIoKd9FV5Dbv0Fr
# IdQgXT8UUIgcVQOgry0yqNriUL2DazlwXNHTd5XtuM21Bp9Kr+78wPtSloyqkMhn
# uIYpii8JBcM2TH5Ro9MPFLVOtSlYKm7f6fR7Nr5hX0PVSKlxE2d1kd5YPp//WTVW
# B0eX/8X7ja91ycLJNl+5cXzWDZlogRN3MKsLIHTYbGzMPIt1a+um/iAmB1JG8yeO
# GtPPO/H8rEScjprY4FOOB/WK5xafqjzvvZHidh9b8fFz06Z0MERfEpNC5f6KIGrQ
# 3i+3fTKUh1YL0B09Z46S6aZ8ZgvET9y6S9/hIRZq7sWvIUdytRkPOMOKi3lCvRQG
# DHlJvvI=
# SIG # End signature block
