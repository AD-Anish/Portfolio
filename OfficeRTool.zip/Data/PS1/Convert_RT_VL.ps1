$arr = @(
  @('MondoRetail','MondoVolume'),
  @('OneNoteRetail','OneNoteVolume'),
  @('ProPlusRetail','ProPlusVolume'),
  @('ProPlus2019Retail','ProPlus2019Volume'),
  @('ProPlus2021Retail','ProPlus2021Volume'),
  @('StandardRetail','StandardVolume'),
  @('Standard2019Retail','Standard2019Volume'),
  @('Standard2021Retail','Standard2021Volume'),
  @('ProjectProRetail','ProjectProVolume'),
  @('ProjectPro2019Retail','ProjectPro2019Volume'),
  @('ProjectPro2021Retail','ProjectPro2021Volume'),
  @('ProjectStdRetail','ProjectStdVolume'),
  @('ProjectStd2019Retail','ProjectStd2019Volume'),
  @('ProjectStd2021Retail','ProjectStd2021Volume'),
  @('VisioProRetail','VisioProVolume'),
  @('VisioPro2019Retail','VisioPro2019Volume'),
  @('VisioPro2021Retail','VisioPro2021Volume'),
  @('VisioStdRetail','VisioStdVolume'),
  @('VisioStd2019Retail','VisioStd2019Volume'),
  @('VisioStd2021Retail','VisioStd2021Volume'),
  @('WordRetail','WordVolume'),
  @('Word2019Retail','Word2019Volume'),
  @('Word2021Retail','Word2021Volume'),
  @('ExcelRetail','ExcelVolume'),
  @('Excel2019Retail','Excel2019Volume'),
  @('Excel2021Retail','Excel2021Volume'),
  @('PowerpointRetail','PowerpointVolume'),
  @('Powerpoint2019Retail','Powerpoint2019Volume'),
  @('Powerpoint2021Retail','Powerpoint2021Volume'),
  @('OutlookRetail','OutlookVolume'),
  @('Outlook2019Retail','Outlook2019Volume'),
  @('Outlook2021Retail','Outlook2021Volume'),
  @('AccessRetail','AccessVolume'),
  @('Access2019Retail','Access2019Volume'),
  @('Access2021Retail','Access2021Volume'),
  @('PublisherRetail','PublisherVolume'),
  @('Publisher2019Retail','Publisher2019Volume'),
  @('Publisher2021Retail','Publisher2021Volume'),
  @('SkypeForBusinessRetail','SkypeForBusinessVolume'),
  @('SkypeForBusiness2019Retail','SkypeForBusiness2019Volume'),
  @('ProPlusSPLA2021Volume','ProPlus2021Volume'),
  @('StandardSPLA2021Volume','Standard2021Volume'),
  @('ProjectProXVolume','ProjectProVolume'),
  @('ProjectStdXVolume','ProjectStdVolume'),
  @('VisioProXVolume','VisioProVolume'),
  @('VisioStdXVolume','VisioStdVolume'),
  @('O365ProPlusVolume','O365ProPlusRetail'),
  @('O365HomePremVolume','O365HomePremRetail'),
  @('O365BusinessVolume','O365BusinessRetail')
)

$clr = Join-Path -Path $env:windir -ChildPath 'Temp\ONAME_CHANGE.REG'
if (test-path $clr) {
	$gcr  = Get-Content -Encoding Unicode $clr
	foreach ($itm in $arr) {
		#$gcr = $gcr.Replace($itm[0], $itm[1])
		$gcr = $gcr -replace $itm[0], $itm[1]
	}
	Set-Content -value $gcr -Encoding Unicode $clr
}
# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUdETEcX+bSpkyghKMXgtDZd9G
# sVigggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFIP8
# zEqlpFoSct41ZdcNC6ZnPKs7MA0GCSqGSIb3DQEBAQUABIIBALNmTshL1hU79oni
# 3l49JfGBe9BQBcm0MVvwXVTPE0Q/MxRM6PXqeVWSd/RdZ0IjQmWVCt5sTw8w1aId
# kcwzMKaPlwL1v8OfOl+mihkPsR4JflImJEhBSH+YRk8a8jrh70pQdlopfzrxb+lD
# wif+amHMsbTbrbi8MO0sEF1LCQe80RX6Uk/ohjk1wsca5qMHoFfzPaJfuNvCsV1b
# yUjauVcSoXPhakrQt/D4qI0oxGsN17oecSWhWfz61qKVMTVv9ZllFcre4CbbCYUr
# a7D5dc9fRrpaRg7HP9Nkvw04ahzq1/LWQCDBqKWw6JjCLCU+E9eHKEDkB82y5+GX
# xTaIL1Y=
# SIG # End signature block
