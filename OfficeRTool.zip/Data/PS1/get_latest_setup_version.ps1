function get_latest_version {
	
	$filter = ' \/<>()'
	$uri   = 'https://learn.microsoft.com/en-us/officeupdates/odt-release-history'
	
	<# Origional version, have better one #>
	$regex = '[setup.exe]*[version]*[16].[0-9].[0-9][0-9][0-9][0-9][0-9].[0-9][0-9][0-9][0-9][0-9]'
	
	<# 16.x Prefix #>
	$regex_Lite = '^16\.[0-9]\.[0-9][0-9][0-9][0-9][0-9]\.[0-9][0-9][0-9][0-9][0-9]$'
	<# Start with <p> ~ *** ~ Group A, Setup.exe ~ *** ~ Group B, version ~ *** ~ Group C, 16.x Prefix ~ *** ~ end with </p> #>
	$regex_Full = '^\<p\>(.*)setup\.exe(.*)version(.*)16\.[0-9]\.[0-9][0-9][0-9][0-9][0-9]\.[0-9][0-9][0-9][0-9][0-9](.*)\<\/p\>$'
	
	try {
	  $ProgressPreference = 'SilentlyContinue'    # Subsequent calls do not display UI.	
	  $content = @(iwr -Uri $uri).RawContent 
	  $ProgressPreference = 'Continue'            # Subsequent calls do display UI.
	}
	catch { 
	  $ProgressPreference = 'Continue'            # Subsequent calls do display UI.
	  return
	}

	foreach ($val in @($content.Split("`n"))) {
	  if ($val -match $regex_Full) {
	    sv -Name "info" -Value $val -Scope global -force
		break
	  }
	}

	if ($info) {
	  $version = $info.Split($filter) | where {$_ -match $regex_Lite} | Select-Object -Last 1
	}
	if ($version) {
	  return $version
	}
}

get_latest_version;