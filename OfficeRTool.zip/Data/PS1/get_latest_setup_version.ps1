function get_latest_version {
	
	$filter = ' \/<>()'
	$uri   = 'https://learn.microsoft.com/en-us/officeupdates/odt-release-history'
	
	<# Origional version, have better one #>
	$regex = '[setup.exe]*[version]*[16].[0-9].[0-9][0-9][0-9][0-9][0-9].[0-9][0-9][0-9][0-9][0-9]'
	
	<# 16.x Prefix #>
	$regex_Lite = '^16\.[0-9]\.[0-9][0-9][0-9][0-9][0-9]\.[0-9][0-9][0-9][0-9][0-9]$'
	<# Start with <p> ~ *** ~ Group A, Setup.exe ~ *** ~ Group B, version ~ *** ~ Group C, 16.x Prefix ~ *** ~ end with </p> #>
	$regex_Full = '^\<p\>(.*)setup\.exe(.*)version(.*)16\.[0-9]\.[0-9][0-9][0-9][0-9][0-9]\.[0-9][0-9][0-9][0-9][0-9](.*)\<\/p\>$'
	
	try {
	  $ProgressPreference = 'SilentlyContinue'    # Subsequent calls do not display UI.	
	  $content = @(iwr -Uri $uri).RawContent 
	  $ProgressPreference = 'Continue'            # Subsequent calls do display UI.
	}
	catch { 
	  $ProgressPreference = 'Continue'            # Subsequent calls do display UI.
	  return
	}

	foreach ($val in @($content.Split("`n"))) {
	  if ($val -match $regex_Full) {
	    sv -Name "info" -Value $val -Scope global -force
		break
	  }
	}

	if ($info) {
	  $version = $info.Split($filter) | where {$_ -match $regex_Lite} | Select-Object -Last 1
	}
	if ($version) {
	  return $version
	}
}

get_latest_version;
# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU468P++DCw0FKZabvkJv+od4z
# BoqgggM2MIIDMjCCAhqgAwIBAgIQbKiwCjDfualNvXPhtKXHTjANBgkqhkiG9w0B
# AQsFADAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHhcNMjQwMTA1
# MTkzNTQ4WhcNMjUwMTA1MTk1NTQ4WjAgMR4wHAYDVQQDDBVhZG1pbkBvZmZpY2Vy
# dG9vbC5vcmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHIw9LPJ4d
# Wgyqk/AbYJGa25Y/akIr5P1k/7hfJXIQ2g/KjduT8igZXZaafvIcC0SfCztyHnPE
# AhwH4ginwHFM8Rpow5agNFXchqJjKx2zfQVdm3adh06cBvU3NkthCEGf75Zx53iU
# /LgWm4qOfwIoDlF9XXe1Xmp28ohJ0M0bI1T2MbtaVp5Chtb0UXIVW5OvDVos4lZE
# 871xiJvRoXUw3cQPkoXBL9pQJhJxVBmXZ+ZWPH7H2hiBhJFyWpOGtkY5ySqe6snP
# EPraYb8zqvYgUpSBnR3ZiU/Nx2XqEHjJbgVFRz9yntCba0jhRWc5obRygjqDhtwa
# c5qlk+1cDFKtAgMBAAGjaDBmMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAgBgNVHREEGTAXghVhZG1pbkBvZmZpY2VydG9vbC5vcmcwHQYDVR0O
# BBYEFMX1KbAq4tt4MXJ+syl/0QJbXOmJMA0GCSqGSIb3DQEBCwUAA4IBAQCRxQVW
# +bYIQP65OWJ3rg9604pmsskTechPLP7+6P/LZMIxGh9Y5leqMpwqSlPRx9xX1BjO
# 5zdvRVHazBXfab7SQRLu8fYArj7h3uYXKbR75W79aOOif6CeZQbDNmFLRfCVpITV
# VUSn1mDg0w/6Pr4Za4ITl83TSYnHASMnpVhvQPW1mj97ENp953RjJx6WGiRsm5kL
# cE1A7dOemkQyvJn9L17+HBfvzOio56YnW5ZBShfu18+oY3Kux8DfEqVHzRnoxqBr
# g478cAdaBy/2mQJ0uGAZAzROkBTCCga7A54mrCJCoeJAx1R/umzXeCqat7zRVqQ3
# QcY5pmpiCo2VrsTWMYIB1TCCAdECAQEwNDAgMR4wHAYDVQQDDBVhZG1pbkBvZmZp
# Y2VydG9vbC5vcmcCEGyosAow37mpTb1z4bSlx04wCQYFKw4DAhoFAKB4MBgGCisG
# AQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFMF+
# imLi/Yl5bMPr0Ssf/RnBo9w9MA0GCSqGSIb3DQEBAQUABIIBAI9woiwEVIs8BCh2
# UxYMO7vpDceiXg+RyBftOzFawvfipCMN70mlU0KUU4kRkEPEfSpEP3mDBf1ytaNF
# QfPI3ChFAfRplP9D+zG1NvYsBu1KarUb3j+0wYlxexKuwFrk003BMxypNlgT7i2b
# 3DLUJLDrYcjz1reurn51HDDIcgg05d42eqVBA1Y89o8QUsypowCyoIJKHiU+HQ3t
# kd1WKS32vZNZ2fydmvRmA994sTpPdTeeOP652n7VLhqEB2AwONAmmJ+Mp2WhNnDx
# PtBpg4t04La9TezWUdWfmTOwjeMWmq+R1cPhDlUTbQzmJbaMXiHixo8ZT2LHuoAD
# Y6jNqPQ=
# SIG # End signature block
